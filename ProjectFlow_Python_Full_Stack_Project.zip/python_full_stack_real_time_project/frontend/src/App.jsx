import React, { useEffect, useMemo, useState } from 'react';
import axios from 'axios';
import { Activity, CheckCircle2, Circle, ClipboardList, LogOut, Plus, Search, Trash2, Pencil, X, CalendarDays, ArrowUpRight } from 'lucide-react';

const API = 'http://127.0.0.1:8000/api';
const emptyForm = { title: '', description: '', priority: 'medium', status: 'todo', due_date: '' };
const labels = { todo: 'To do', in_progress: 'In progress', done: 'Completed' };
const prettyDate = (d) => d ? new Date(`${d}T00:00:00`).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' }) : 'No due date';

export default function App() {
  const [token, setToken] = useState(localStorage.getItem('pf_token') || '');
  const [user, setUser] = useState(null);
  const [authMode, setAuthMode] = useState('login');
  const [auth, setAuth] = useState({ username: '', email: '', password: '' });
  const [tasks, setTasks] = useState([]);
  const [stats, setStats] = useState({ total: 0, todo: 0, in_progress: 0, done: 0, high_priority: 0 });
  const [query, setQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [priorityFilter, setPriorityFilter] = useState('all');
  const [form, setForm] = useState(emptyForm);
  const [editing, setEditing] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const api = useMemo(() => axios.create({ baseURL: API, headers: token ? { Authorization: `Token ${token}` } : {} }), [token]);

  async function refresh() {
    if (!token) return;
    try {
      const [taskRes, statRes, userRes] = await Promise.all([api.get('/tasks/'), api.get('/dashboard/'), api.get('/auth/me/')]);
      setTasks(taskRes.data); setStats(statRes.data); setUser(userRes.data);
    } catch (e) {
      if (e.response?.status === 401) logout();
      else setError('Could not connect to the backend. Start Django on port 8000 and try again.');
    }
  }
  useEffect(() => { if (token) refresh(); }, [token]);

  const visibleTasks = tasks.filter(t => {
    const matchesQuery = `${t.title} ${t.description}`.toLowerCase().includes(query.toLowerCase());
    return matchesQuery && (statusFilter === 'all' || t.status === statusFilter) && (priorityFilter === 'all' || t.priority === priorityFilter);
  });

  async function submitAuth(e) {
    e.preventDefault(); setError(''); setLoading(true);
    try {
      const endpoint = authMode === 'login' ? '/auth/login/' : '/auth/register/';
      const response = await axios.post(`${API}${endpoint}`, auth);
      const key = response.data.token;
      localStorage.setItem('pf_token', key); setToken(key);
    } catch (e) {
      const data = e.response?.data;
      setError(data ? Object.entries(data).map(([k,v]) => `${k}: ${Array.isArray(v) ? v.join(' ') : typeof v === 'object' ? JSON.stringify(v) : v}`).join(' · ') : 'Unable to reach the server. Check that Django is running.');
    } finally { setLoading(false); }
  }
  function logout() {
    localStorage.removeItem('pf_token'); setToken(''); setUser(null); setTasks([]); setStats({ total: 0, todo: 0, in_progress: 0, done: 0, high_priority: 0 });
  }
  function openCreate() { setEditing(null); setForm(emptyForm); setShowForm(true); setError(''); }
  function openEdit(task) { setEditing(task.id); setForm({ title: task.title, description: task.description, priority: task.priority, status: task.status, due_date: task.due_date || '' }); setShowForm(true); setError(''); }
  async function saveTask(e) {
    e.preventDefault(); setError('');
    try {
      const payload = { ...form, due_date: form.due_date || null };
      if (editing) await api.patch(`/tasks/${editing}/`, payload);
      else await api.post('/tasks/', payload);
      setShowForm(false); setForm(emptyForm); setEditing(null); await refresh();
    } catch (e) { setError(e.response?.data ? JSON.stringify(e.response.data) : 'Could not save task.'); }
  }
  async function toggleDone(task) {
    try { await api.patch(`/tasks/${task.id}/`, { status: task.status === 'done' ? 'todo' : 'done' }); await refresh(); }
    catch { setError('Could not update task.'); }
  }
  async function deleteTask(task) {
    if (!window.confirm(`Delete "${task.title}"?`)) return;
    try { await api.delete(`/tasks/${task.id}/`); await refresh(); }
    catch { setError('Could not delete task.'); }
  }

  if (!token) return <main className="auth-shell"><div className="auth-art"><div className="brand"><span className="brand-icon"><ClipboardList size={22}/></span> ProjectFlow</div><div className="art-copy"><span className="eyebrow">YOUR WORKSPACE, REIMAGINED</span><h1>Make room for<br/><em>great work.</em></h1><p>Plan clearly. Prioritize what matters. Turn your to-do list into momentum.</p><div className="mini-board"><div className="mini-line"><span className="mini-dot green"></span> Ship project dashboard <b>Done</b></div><div className="mini-line"><span className="mini-dot blue"></span> Review API endpoints <b>Today</b></div><div className="mini-line"><span className="mini-dot orange"></span> Prepare sprint notes <b>Next</b></div></div></div><div className="art-footer">A simple space to get things done.</div></div><div className="auth-panel"><form className="auth-card" onSubmit={submitAuth}><div className="mobile-brand"><span className="brand-icon"><ClipboardList size={22}/></span> ProjectFlow</div><span className="eyebrow">{authMode === 'login' ? 'WELCOME BACK' : 'GET STARTED'}</span><h2>{authMode === 'login' ? 'Sign in to your workspace' : 'Create your workspace'}</h2><p className="muted">{authMode === 'login' ? 'Pick up where you left off.' : 'A few details and you are ready to go.'}</p>{error && <div className="error">{error}</div>}<label>Username<input required value={auth.username} onChange={e=>setAuth({...auth, username:e.target.value})} placeholder="Your username" autoComplete="username"/></label>{authMode === 'register' && <label>Email address<input required type="email" value={auth.email} onChange={e=>setAuth({...auth,email:e.target.value})} placeholder="you@example.com" autoComplete="email"/></label>}<label>Password<input required minLength="8" type="password" value={auth.password} onChange={e=>setAuth({...auth,password:e.target.value})} placeholder="At least 8 characters" autoComplete={authMode === 'login' ? 'current-password' : 'new-password'}/></label><button className="primary full" disabled={loading}>{loading ? 'Please wait…' : authMode === 'login' ? 'Sign in' : 'Create account'} <ArrowUpRight size={17}/></button><p className="switch">{authMode === 'login' ? 'New to ProjectFlow?' : 'Already have an account?'} <button type="button" onClick={()=>{setAuthMode(authMode==='login'?'register':'login');setError('')}}>{authMode==='login'?'Create an account':'Sign in'}</button></p><p className="auth-note">Your tasks are private to your account.</p></form></div></main>;

  return <div className="app-shell"><aside className="sidebar"><div className="brand"><span className="brand-icon"><ClipboardList size={22}/></span> ProjectFlow</div><div className="workspace-label">WORKSPACE</div><button className="nav-item active"><Activity size={18}/> Overview</button><button className="nav-item" onClick={()=>{setStatusFilter('todo')}}><Circle size={18}/> My tasks <span className="nav-count">{stats.todo}</span></button><button className="nav-item" onClick={()=>setStatusFilter('done')}><CheckCircle2 size={18}/> Completed</button><div className="sidebar-bottom"><div className="profile"><div className="avatar">{(user?.username||'U').slice(0,1).toUpperCase()}</div><div className="profile-info"><b>{user?.username || 'Your account'}</b><small>Personal workspace</small></div><button className="icon-btn" title="Sign out" onClick={logout}><LogOut size={17}/></button></div></div></aside><main className="main"><header className="topbar"><div><div className="breadcrumb">Workspace <span>/</span> Overview</div><h1>Good to see you{user?.username ? `, ${user.username}` : ''} <span className="wave">✦</span></h1><p className="muted">Here's what's happening with your work today.</p></div><button className="primary" onClick={openCreate}><Plus size={18}/> New task</button></header>
    {error && <div className="error global-error"><span>{error}</span><button onClick={()=>setError('')}><X size={16}/></button></div>}
    <section className="stats-grid"><Stat icon={<ClipboardList/>} label="Total tasks" value={stats.total} note="Across your workspace" tone="violet"/><Stat icon={<Circle/>} label="To do" value={stats.todo} note="Ready to get started" tone="blue"/><Stat icon={<Activity/>} label="In progress" value={stats.in_progress} note="Currently underway" tone="orange"/><Stat icon={<CheckCircle2/>} label="Completed" value={stats.done} note={`${stats.total ? Math.round(stats.done/stats.total*100) : 0}% of all tasks`} tone="green"/></section>
    <section className="tasks-panel"><div className="panel-heading"><div><h2>Your tasks</h2><p className="muted">Keep track of the details that move you forward.</p></div><span className="task-total">{visibleTasks.length} {visibleTasks.length===1?'task':'tasks'}</span></div><div className="filters"><div className="search-box"><Search size={17}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search tasks..."/></div><select value={statusFilter} onChange={e=>setStatusFilter(e.target.value)}><option value="all">All statuses</option><option value="todo">To do</option><option value="in_progress">In progress</option><option value="done">Completed</option></select><select value={priorityFilter} onChange={e=>setPriorityFilter(e.target.value)}><option value="all">All priorities</option><option value="high">High priority</option><option value="medium">Medium priority</option><option value="low">Low priority</option></select></div>
    {visibleTasks.length ? <div className="task-list">{visibleTasks.map(task=><article className={`task-row ${task.status==='done'?'is-done':''}`} key={task.id}><button className={`complete-toggle ${task.status==='done'?'checked':''}`} onClick={()=>toggleDone(task)} title="Toggle completion">{task.status==='done'?<CheckCircle2 size={21}/>:<Circle size={21}/>}</button><div className="task-body"><div className="task-title-line"><h3>{task.title}</h3><span className={`priority ${task.priority}`}>{task.priority} priority</span></div>{task.description && <p>{task.description}</p>}<div className="task-meta"><span className={`status ${task.status}`}>{labels[task.status]}</span><span><CalendarDays size={14}/>{prettyDate(task.due_date)}</span></div></div><div className="task-actions"><button className="icon-btn" title="Edit task" onClick={()=>openEdit(task)}><Pencil size={16}/></button><button className="icon-btn danger-hover" title="Delete task" onClick={()=>deleteTask(task)}><Trash2 size={16}/></button></div></article>)}</div> : <div className="empty-state"><div className="empty-icon"><ClipboardList size={26}/></div><h3>{tasks.length?'No tasks match those filters':'Your workspace is a blank canvas'}</h3><p>{tasks.length?'Try changing your search or filters.':'Create your first task and start building momentum.'}</p>{!tasks.length && <button className="primary" onClick={openCreate}><Plus size={17}/> Create your first task</button>}</div>}
    </section><footer className="footer">ProjectFlow <span>·</span> Built for focus, one task at a time.</footer></main>
    {showForm && <div className="modal-backdrop" onMouseDown={e=>{if(e.target===e.currentTarget)setShowForm(false)}}><form className="task-modal" onSubmit={saveTask}><div className="modal-head"><div><span className="eyebrow">{editing?'MAKE IT BETTER':'ADD TO YOUR WORKSPACE'}</span><h2>{editing?'Edit task':'Create a new task'}</h2></div><button type="button" className="icon-btn" onClick={()=>setShowForm(false)}><X size={20}/></button></div><label>Task title<input required maxLength="160" autoFocus value={form.title} onChange={e=>setForm({...form,title:e.target.value})} placeholder="e.g. Finish project proposal"/></label><label>Description <span className="optional">Optional</span><textarea rows="3" value={form.description} onChange={e=>setForm({...form,description:e.target.value})} placeholder="Add a few details to help you get started..."/></label><div className="form-grid"><label>Priority<select value={form.priority} onChange={e=>setForm({...form,priority:e.target.value})}><option value="low">Low</option><option value="medium">Medium</option><option value="high">High</option></select></label><label>Status<select value={form.status} onChange={e=>setForm({...form,status:e.target.value})}><option value="todo">To do</option><option value="in_progress">In progress</option><option value="done">Completed</option></select></label></div><label>Due date <span className="optional">Optional</span><input type="date" value={form.due_date} onChange={e=>setForm({...form,due_date:e.target.value})}/></label>{error && <div className="error">{error}</div>}<div className="modal-actions"><button type="button" className="secondary" onClick={()=>setShowForm(false)}>Cancel</button><button className="primary"><Plus size={17}/>{editing?'Save changes':'Create task'}</button></div></form></div>}
  </div>;
}
function Stat({icon,label,value,note,tone}) { return <article className="stat-card"><div className={`stat-icon ${tone}`}>{icon}</div><div className="stat-label">{label}</div><div className="stat-value">{value}</div><div className="stat-note">{note}</div></article>; }

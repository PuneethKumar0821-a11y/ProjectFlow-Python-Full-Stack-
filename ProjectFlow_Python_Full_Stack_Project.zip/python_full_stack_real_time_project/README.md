# ProjectFlow — Python Full Stack Project & Task Management Portal

A runnable full-stack project inspired by the internship report's Python, Django, Django REST Framework, React, MySQL, Bootstrap, and API-testing stack.

## Features
- Register and log in with token authentication
- Create, view, edit, complete, and delete personal tasks
- Search tasks and filter by status / priority
- Dashboard summary cards
- REST API with authenticated, user-owned records
- Responsive React interface
- SQLite works out of the box; optional MySQL configuration is included

> This is a practical portfolio/demo project, not a claim that it was deployed for a real company. Change sample branding and document your own work before submitting it.

## Requirements
- Python 3.10+
- Node.js 18+
- npm

## 1. Run the backend
Open a terminal in `backend/`:

```bash
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
python manage.py migrate
python manage.py runserver
```

Backend: http://127.0.0.1:8000  
API root: http://127.0.0.1:8000/api/

Create an admin account if desired:
```bash
python manage.py createsuperuser
```
Admin: http://127.0.0.1:8000/admin/

## 2. Run the frontend
In a second terminal, open `frontend/`:

```bash
npm install
npm run dev
```
Open the URL printed by Vite (normally http://localhost:5173).

## Optional MySQL
Install and start MySQL, create a database (for example `projectflow_db`), then set environment variables before running migrations:

```bash
# Windows PowerShell example
$env:DB_ENGINE="mysql"
$env:DB_NAME="projectflow_db"
$env:DB_USER="root"
$env:DB_PASSWORD="your_password"
$env:DB_HOST="127.0.0.1"
$env:DB_PORT="3306"
```
Install `mysqlclient` using a compatible system setup if you use MySQL. SQLite is the default for easy local setup.

## API endpoints
- `POST /api/auth/register/` — `{ "username": "...", "email": "...", "password": "..." }`
- `POST /api/auth/login/` — `{ "username": "...", "password": "..." }`
- `GET /api/auth/me/`
- `GET, POST /api/tasks/`
- `GET, PUT, PATCH, DELETE /api/tasks/<id>/`
- `GET /api/dashboard/`

Send `Authorization: Token <key>` for protected endpoints.

## Suggested demonstration
1. Register a user.
2. Create several tasks with different due dates and priorities.
3. Search and filter tasks.
4. Mark a task complete, then edit or delete one.
5. Show the dashboard and demonstrate API requests in Postman.

## Project structure
```text
backend/   Django project, REST API, authentication, database models
frontend/  React + Vite responsive single-page application
```

from django.contrib.auth import get_user_model
from rest_framework.test import APITestCase
from rest_framework.authtoken.models import Token
from rest_framework import status

class TaskAPITests(APITestCase):
    def setUp(self):
        user = get_user_model().objects.create_user(username="demo", password="strong-pass-123")
        self.client.credentials(HTTP_AUTHORIZATION=f"Token {Token.objects.create(user=user).key}")

    def test_create_and_list_task(self):
        response = self.client.post("/api/tasks/", {
            "title": "Build portfolio", "description": "Add project screenshots",
            "priority": "high", "status": "todo"
        }, format="json")
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        listing = self.client.get("/api/tasks/")
        self.assertEqual(listing.status_code, status.HTTP_200_OK)
        self.assertEqual(len(listing.data), 1)
        self.assertEqual(listing.data[0]["title"], "Build portfolio")

from django.contrib.auth import get_user_model
from django.db.models import Q, Count
from rest_framework import generics, permissions, status
from rest_framework.authtoken.models import Token
from rest_framework.response import Response
from rest_framework.views import APIView
from .models import Task
from .serializers import RegisterSerializer, UserSerializer, TaskSerializer

User = get_user_model()

class RegisterView(generics.CreateAPIView):
    queryset = User.objects.all()
    serializer_class = RegisterSerializer
    permission_classes = [permissions.AllowAny]
    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.save()
        token, _ = Token.objects.get_or_create(user=user)
        return Response({"token": token.key, "user": UserSerializer(user).data}, status=status.HTTP_201_CREATED)

class CurrentUserView(APIView):
    def get(self, request):
        return Response(UserSerializer(request.user).data)

class TaskListCreateView(generics.ListCreateAPIView):
    serializer_class = TaskSerializer
    def get_queryset(self):
        qs = Task.objects.filter(owner=self.request.user)
        search = self.request.query_params.get("search", "").strip()
        status_filter = self.request.query_params.get("status", "")
        priority = self.request.query_params.get("priority", "")
        if search:
            qs = qs.filter(Q(title__icontains=search) | Q(description__icontains=search))
        if status_filter in dict(Task.Status.choices):
            qs = qs.filter(status=status_filter)
        if priority in dict(Task.Priority.choices):
            qs = qs.filter(priority=priority)
        return qs
    def perform_create(self, serializer):
        serializer.save(owner=self.request.user)

class TaskDetailView(generics.RetrieveUpdateDestroyAPIView):
    serializer_class = TaskSerializer
    def get_queryset(self):
        return Task.objects.filter(owner=self.request.user)

class DashboardView(APIView):
    def get(self, request):
        qs = Task.objects.filter(owner=request.user)
        counts = {row["status"]: row["count"] for row in qs.values("status").annotate(count=Count("id"))}
        return Response({
            "total": qs.count(),
            "todo": counts.get(Task.Status.TODO, 0),
            "in_progress": counts.get(Task.Status.IN_PROGRESS, 0),
            "done": counts.get(Task.Status.DONE, 0),
            "high_priority": qs.filter(priority=Task.Priority.HIGH).exclude(status=Task.Status.DONE).count(),
        })

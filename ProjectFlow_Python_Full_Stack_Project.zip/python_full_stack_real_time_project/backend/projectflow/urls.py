from django.contrib import admin
from django.urls import path, include
from rest_framework.authtoken.views import obtain_auth_token
from tasks.views import RegisterView, CurrentUserView, TaskListCreateView, TaskDetailView, DashboardView

urlpatterns = [
    path("admin/", admin.site.urls),
    path("api/auth/register/", RegisterView.as_view(), name="register"),
    path("api/auth/login/", obtain_auth_token, name="login"),
    path("api/auth/me/", CurrentUserView.as_view(), name="current-user"),
    path("api/tasks/", TaskListCreateView.as_view(), name="task-list"),
    path("api/tasks/<int:pk>/", TaskDetailView.as_view(), name="task-detail"),
    path("api/dashboard/", DashboardView.as_view(), name="dashboard"),
]
